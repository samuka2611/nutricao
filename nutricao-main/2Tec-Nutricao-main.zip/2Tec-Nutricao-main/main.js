alert("Oi Lucas");
console.log("Oi João");

var titulo = document.querySelector("h1");
titulo.textContent = "Lucas Nutrição";

var trPaulo = document.querySelector("#paulo");

console.log(trPaulo);

var tdPeso = trPaulo.querySelector(".info-peso");
tdPeso.textContent = "150";
